Cara run Di Vps

cd war
screen -R bot  [ Sesuai Nama token ya]
chmod +x war
./war bot


Terimakasi sudah memakai app go kita

======== Jangan Lupa Belanja di kami ya======
[ P°K-BOTS & ENSCREAMI ]

Open Rent Bot Protect & War: ▾
Type: Go-lang 
Feature: →
>> Sabi War Wer Wor
>> Include AntiJs/ Set AntiJs
» Kickall, Bypass, Cancelall
>> Fast Kick & Purge Ban
>> Protect: Link, Invite, Join, Kick, Cancel, DII
» Admin List, Bot List, Whitelist

>> Script Go War/Pro Suport Selfbot New Lib

>> Vultr 4core 8Gb fullgar IDR 90k
>> 10 Token IDR 45k Add Friends Manual
>> App Go-lang + Ip 4/8 IDR 150K
» Sedia jasa open protect group 30k / 5 group

>> Vcc $1 IDR 10k
>> Vcc MC Indo, Visa Indo,Aus,Uk & German
>>Suport claim trial cloud & App Prem

>> Akun Panel
>> Vultr $250 IDR 150k
>> AzureFt $200 IDR 80k
>> GCP $300 IDR 250k
>> Linode $100 IDR 125k
>> Alibaba 1/1 or 2/4 IDR 35k

Note: →
>> Minimal Rent 5 Bots
>> Rent 10 Atau Lebih
>> Ingat pasti ada kejutan menarik lainnya
(Minat? Tanya-tanya? Pc ID Dibawah)
Contact Person: →
↳ Pais » 
https://line.me/ti/p/~belajarbg
↳ jema » 
https://line.me/ti/p/~gukken97.
↳ juan »   
line.me/ti/p/~screamcrlos

↳ DollyPK »   
https://wa.me/62889801923880

Join Group app murah wa 
https://chat.whatsapp.com/JEgnM5VA6k18eZKhgbf4tp

>>Notif Dapoer Apps
https://whatsapp.com/channel/0029Vabl1WuFsn0fzpIuKj2I