from chr_thrift import Thrift
import traceback, json, os, random, time, sys


def decoder():
    res_bytes = sys.argv[1]
    isinya = bytearray(json.loads(res_bytes.replace("\n", "").replace(" ", ",")))
    if "addFriendByMid" not in str(isinya):
        print("something line error :", isinya)
        return "something line error"
    
    res = Thrift().TCompactProtocol(isinya).res
    # print(res)

    if "error" not in res:
        return "Success"

    reason_msg = {
        1: "suspended user",
        3: "Friendlist Full !!!",
        4: "ABUSE_BLOCK / request blocked",
    }

    try:text_msg = reason_msg[res["error"]["code"]]
    except:
        print("something line error :", res)
        text_msg = "something line error"

    return text_msg

print(decoder())